﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace VivetAssetBundlingApi.AssetBundling
{
    public class Data_
    {
        public static List<GameObject> Assets = new List<GameObject>();
        public static int ObjsLoaded = 0;
        public enum BundlingType
        {
            FromFilePath,
            FromBytes,
            FromUrl,
        }
    }
}
