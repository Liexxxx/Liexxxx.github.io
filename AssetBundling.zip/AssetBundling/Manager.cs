﻿using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
using VivetAssetBundlingApi.AssetBundling;

namespace VivetAssetBundlingApi
{
    public class Manager : MonoBehaviour
    {
        public static Manager Instance;

        private void Awake()
        {
            if (Instance == null)
                Instance = this;
            else
                Destroy(gameObject);
        }

        public void LoadAssetBundle(
            Data_.BundlingType bundleType,
            string path = "",
            byte[] bytes = null,
            string url = "")
        {
            switch (bundleType)
            {
                case Data_.BundlingType.FromFilePath:
                    if (!string.IsNullOrEmpty(path))
                        StartCoroutine(LoadFromFile(path));
                    break;

                case Data_.BundlingType.FromBytes:
                    if (bytes != null && bytes.Length > 0)
                        StartCoroutine(LoadFromBytes(bytes));
                    break;

                case Data_.BundlingType.FromUrl:
                    if (!string.IsNullOrEmpty(url))
                        StartCoroutine(LoadFromUrl(url));
                    break;
            }
        }
        private IEnumerator LoadFromFile(string path)
        {
            var bundle = AssetBundle.LoadFromFile(path);
            yield return null;

            HandleBundle(bundle);
        }
        private IEnumerator LoadFromBytes(byte[] bytes)
        {
            var bundle = AssetBundle.LoadFromMemory(bytes);
            yield return null;

            HandleBundle(bundle);
        }
        private IEnumerator LoadFromUrl(string url)
        {
            UnityWebRequest request = UnityWebRequestAssetBundle.GetAssetBundle(url);
            yield return request.SendWebRequest();

            if (request.result != UnityWebRequest.Result.Success)
                yield break;

            AssetBundle bundle = DownloadHandlerAssetBundle.GetContent(request);
            HandleBundle(bundle);
        }
        private void HandleBundle(AssetBundle bundle)
        {
            if (bundle == null) return;

            foreach (var name in bundle.GetAllAssetNames())
            {
                GameObject prefab = bundle.LoadAsset<GameObject>(name);
                if (prefab != null)
                {
                    var obj = Instantiate(prefab, Vector3.zero, Quaternion.identity);
                    Data_.Assets.Add(obj);  
                    Data_.ObjsLoaded++;
                    break;
                }
            }
            bundle.Unload(false);
        }
    }
}
